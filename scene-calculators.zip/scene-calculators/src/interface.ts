export interface CalculatorProps {
  type: "girðing" | "pallur";
}

export interface TopBannerProps {
  heading: string;
  paragraph: JSX.Element;
}

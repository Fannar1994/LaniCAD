import React, { useState, useMemo } from 'react';
import styled from 'styled-components';
import { CalculatorPageLayout } from '../shared/calculator-page-layout';

const Container = styled.div`
  max-width: 1000px;
  margin: 0 auto;
  padding: 20px;
  font-family: system-ui, -apple-system, sans-serif;
`;

const FormContainer = styled.div`
  margin-bottom: 30px;
`;

const FormGroup = styled.div`
  margin-bottom: 20px;
`;

const Label = styled.label`
  display: block;
  margin-bottom: 10px;
  font-weight: 500;
`;

const RadioGroup = styled.div`
  display: flex;
  gap: 15px;
`;

const RadioLabel = styled.label`
  display: flex;
  align-items: center;
  cursor: pointer;
`;

const RadioInput = styled.input`
  margin-right: 8px;
  width: 18px;
  height: 18px;
`;

const TextInput = styled.input`
  width: 100%;
  max-width: 300px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
`;

const DateInput = styled.input`
  width: 100%;
  max-width: 300px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
`;

const CalculateButton = styled.button`
  width: 100%;
  max-width: 980px;
  padding: 15px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  margin-bottom: 10px;

  &:hover {
    background-color: #0056b3;
  }
`;

const TotalPrice = styled.div`
  font-size: 18px;
  font-weight: 500;

  span {
    color: #666;
  }
`;

interface CalculationResult {
  panelCount: number;
  stoneCount: number;
  clampCount: number;
  totalLength: number;
}

export const Fence: React.FC = () => {
  const [lengthMeters, setLengthMeters] = useState<string>('3.5');
  const [heightMeters, setHeightMeters] = useState<string>('2.0');
  const [thicknessMm, setThicknessMm] = useState<string>('1.1');
  const [totalMeters, setTotalMeters] = useState<string>('');
  const [purchaseType, setPurchaseType] = useState<'leiga' | 'kaupa'>('leiga');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // Price calculation state
  const [showResults, setShowResults] = useState<boolean>(false);

  const calculation = useMemo((): CalculationResult => {
    const requestedM = Number(totalMeters) || 0;
    const panelLength = Number(lengthMeters) || 3.5;

    if (requestedM <= 0) {
      return {
        panelCount: 0,
        stoneCount: 0,
        clampCount: 0,
        totalLength: 0,
      };
    }

    const panelCount = Math.ceil(requestedM / panelLength);
    const stoneCount = panelCount * 2;
    const clampCount = panelCount * 2;
    const totalLength = panelCount * panelLength;

    return {
      panelCount,
      stoneCount,
      clampCount,
      totalLength,
    };
  }, [lengthMeters, totalMeters]);

  // Calculate rental price
  const rentalPrice = useMemo(() => {
    if (!showResults || calculation.panelCount === 0) return 0;

    // Base prices per day (example pricing - adjust as needed)
    const basePricePerPanel = 450; // kr per panel per day
    const pricePerStone = 120; // kr per stone per day
    const pricePerClamp = 80; // kr per clamp per day

    // Height modifier (taller = more expensive)
    const heightModifier = heightMeters === '2.0' ? 1.2 : 1.0;

    // Thickness modifier (thicker = more expensive)
    const thicknessModifier = thicknessMm === '1.7' ? 1.15 : 1.0;

    // Calculate daily price
    const dailyPrice = (
      calculation.panelCount * basePricePerPanel +
      calculation.stoneCount * pricePerStone +
      calculation.clampCount * pricePerClamp
    ) * heightModifier * thicknessModifier;

    // Calculate rental days if dates are provided
    if (purchaseType === 'leiga' && startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
      if (days > 0) {
        return Math.round(dailyPrice * days);
      }
    }

    // Default to 7 days if no dates
    return Math.round(dailyPrice * 7);
  }, [calculation, heightMeters, thicknessMm, purchaseType, startDate, endDate, showResults]);

  const calculatorContent = (
    <Container>
      <FormContainer>
        {/* Length Selection */}
        <FormGroup>
          <Label>Lengd í metrum</Label>
          <RadioGroup>
            <RadioLabel>
              <RadioInput
                type="radio"
                name="length"
                value="3.5"
                checked={lengthMeters === '3.5'}
                onChange={(e) => setLengthMeters(e.target.value)}
              />
              3,5 m
            </RadioLabel>
            <RadioLabel>
              <RadioInput
                type="radio"
                name="length"
                value="2.5"
                checked={lengthMeters === '2.5'}
                onChange={(e) => setLengthMeters(e.target.value)}
              />
              2,5 m
            </RadioLabel>
          </RadioGroup>
        </FormGroup>

        {/* Height Selection */}
        <FormGroup>
          <Label>Hæð í metrum</Label>
          <RadioGroup>
            <RadioLabel>
              <RadioInput
                type="radio"
                name="height"
                value="2.0"
                checked={heightMeters === '2.0'}
                onChange={(e) => setHeightMeters(e.target.value)}
              />
              2,0 m
            </RadioLabel>
            <RadioLabel>
              <RadioInput
                type="radio"
                name="height"
                value="1.2"
                checked={heightMeters === '1.2'}
                onChange={(e) => setHeightMeters(e.target.value)}
              />
              1,2 m
            </RadioLabel>
          </RadioGroup>
        </FormGroup>

        {/* Thickness Selection */}
        <FormGroup>
          <Label>Þykkt á túbu (mm)</Label>
          <RadioGroup>
            <RadioLabel>
              <RadioInput
                type="radio"
                name="thickness"
                value="1.1"
                checked={thicknessMm === '1.1'}
                onChange={(e) => setThicknessMm(e.target.value)}
              />
              1,1 mm
            </RadioLabel>
            <RadioLabel>
              <RadioInput
                type="radio"
                name="thickness"
                value="1.7"
                checked={thicknessMm === '1.7'}
                onChange={(e) => setThicknessMm(e.target.value)}
              />
              1,7 mm
            </RadioLabel>
          </RadioGroup>
        </FormGroup>

        {/* Purchase Type Selection */}
        <FormGroup>
          <RadioGroup>
            <RadioLabel>
              <RadioInput
                type="radio"
                name="purchaseType"
                value="leiga"
                checked={purchaseType === 'leiga'}
                onChange={(e) => setPurchaseType('leiga')}
              />
              Leiga
            </RadioLabel>
            <RadioLabel>
              <RadioInput
                type="radio"
                name="purchaseType"
                value="kaupa"
                checked={purchaseType === 'kaupa'}
                onChange={(e) => setPurchaseType('kaupa')}
              />
              Kaupa
            </RadioLabel>
          </RadioGroup>
        </FormGroup>

        {/* Total Meters Input */}
        <FormGroup>
          <Label htmlFor="total-meters">Samtals metrar</Label>
          <TextInput
            id="total-meters"
            type="number"
            placeholder=""
            min="0"
            step="0.1"
            value={totalMeters}
            onChange={(e) => setTotalMeters(e.target.value)}
          />
        </FormGroup>

        {/* Date inputs - only shown for Leiga */}
        {purchaseType === 'leiga' && (
          <>
            <FormGroup>
              <Label htmlFor="start-date">Upphafsdagur</Label>
              <DateInput
                id="start-date"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </FormGroup>

            <FormGroup>
              <Label htmlFor="end-date">Skiladagur</Label>
              <DateInput
                id="end-date"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </FormGroup>
          </>
        )}

        {/* Calculate Button */}
        <CalculateButton
          onClick={() => {
            if (totalMeters && Number(totalMeters) > 0) {
              setShowResults(true);
            }
          }}
        >
          Reiknaðu leiguverð
        </CalculateButton>

        {/* Results Display */}
        {showResults && calculation.panelCount > 0 && (
          <>
            <TotalPrice style={{ marginTop: '20px', fontSize: '16px', color: '#666' }}>
              Fjöldi panela: <span style={{ fontWeight: 'bold', color: '#333' }}>{calculation.panelCount} stk</span>
            </TotalPrice>
            <TotalPrice style={{ fontSize: '16px', color: '#666' }}>
              Fjöldi steina: <span style={{ fontWeight: 'bold', color: '#333' }}>{calculation.stoneCount} stk</span>
            </TotalPrice>
            <TotalPrice style={{ fontSize: '16px', color: '#666' }}>
              Fjöldi klemmna: <span style={{ fontWeight: 'bold', color: '#333' }}>{calculation.clampCount} stk</span>
            </TotalPrice>
            <TotalPrice style={{ marginTop: '15px', fontSize: '24px', fontWeight: 'bold', color: '#007bff' }}>
              Samtals leiguverð: {rentalPrice.toLocaleString('is-IS')} kr.
              {purchaseType === 'leiga' && startDate && endDate && (
                <span style={{ fontSize: '14px', display: 'block', marginTop: '5px', color: '#666' }}>
                  ({Math.ceil((new Date(endDate).getTime() - new Date(startDate).getTime()) / (1000 * 60 * 60 * 24))} dagar)
                </span>
              )}
            </TotalPrice>
          </>
        )}
      </FormContainer>
    </Container>
  );

  return (
    <CalculatorPageLayout
      heroBackgroundColor="#c9403e"
      title="GIRÐINGAR REIKNIVÉL"
      credibilityStatement="BYKO hefur yfir 60 ára reynslu af byggingarefnum og verkefnalausnum"
      calculatorHeading="Reiknaðu kostnað fyrir girðingu á metttíma!"
      calculator={calculatorContent}
      educationalSections={[
        {
          heading: 'Hæð girðingar',
          explanation:
            'Veldu hæð á girðingunni eftir þörfum. 2,0 m hæð er algengust fyrir fullkomna einangrun og 1,2 m hæð hentar vel fyrir afmörkun svæða.',
        },
        {
          heading: 'Lengd í kringum lóð',
          explanation:
            'Mældu heildarlengd girðingar í metrum. Reikniværinn reiknar sjálfkrafa út fjölda girðingapanela, steina og klemmna sem þarf.',
        },
        {
          heading: 'Þykkt túbu',
          explanation:
            'Velja má á milli 1,1 mm (standard) eða 1,7 mm (styrkri) þykkt á túbum eftir þörfum verkefnisins.',
        },
      ]}
    />
  );
};

import React, { useState, useMemo } from 'react';
import styled from 'styled-components';

const PageContainer = styled.div`
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 20px 40px;
`;

const Section = styled.div`
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 12px;
  padding: 40px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
`;

const SectionTitle = styled.h2`
  color: #1a1a1a;
  font-size: 2em;
  font-weight: 600;
  margin-bottom: 8px;
  letter-spacing: -0.5px;
`;

const SectionSubtitle = styled.p`
  color: #666;
  margin-bottom: 30px;
  font-size: 1.05em;
  line-height: 1.5;
`;

const Container = styled.div`
  max-width: 100%;
`;

const FormContainer = styled.div`
  display: grid;
  gap: 24px;
  margin-bottom: 30px;
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

const Label = styled.label`
  display: block;
  font-weight: 600;
  color: #333;
  font-size: 0.95em;
  letter-spacing: 0.2px;
`;

const RadioGroup = styled.div`
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
`;

const RadioLabel = styled.label`
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 12px 20px;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  background: #fff;
  transition: all 0.2s ease;
  user-select: none;
  
  &:hover {
    border-color: #17a2b8;
    background: #f8fbfc;
  }
  
  &:has(input:checked) {
    border-color: #17a2b8;
    background: #e7f3ff;
    font-weight: 500;
  }
  
  &:has(input:disabled) {
    cursor: not-allowed;
    background: #f5f5f5;
  }
`;

const RadioInput = styled.input`
  width: 20px;
  height: 20px;
  cursor: pointer;
  accent-color: #17a2b8;
  
  &:disabled {
    cursor: not-allowed;
  }
`;

const TextInput = styled.input`
  width: 100%;
  max-width: 400px;
  padding: 12px 16px;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-size: 16px;
  transition: all 0.2s ease;
  
  &:focus {
    outline: none;
    border-color: #17a2b8;
    box-shadow: 0 0 0 3px rgba(23, 162, 184, 0.1);
  }
`;

const DateInput = styled.input`
  width: 100%;
  max-width: 400px;
  padding: 12px 16px;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-size: 16px;
  transition: all 0.2s ease;
  
  &:focus {
    outline: none;
    border-color: #17a2b8;
    box-shadow: 0 0 0 3px rgba(23, 162, 184, 0.1);
  }
`;

const CalculateButton = styled.button`
  width: 100%;
  max-width: 400px;
  padding: 16px 32px;
  background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 17px;
  font-weight: 600;
  cursor: pointer;
  margin-top: 32px;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(23, 162, 184, 0.3);
  letter-spacing: 0.3px;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(23, 162, 184, 0.4);
  }
  
  &:active {
    transform: translateY(0);
  }
`;

const ResultsSection = styled.div`
  margin-top: 40px;
  background: linear-gradient(to bottom, #ffffff 0%, #f8fbfc 100%);
  border: 2px solid #17a2b8;
  border-radius: 12px;
  padding: 32px;
  box-shadow: 0 4px 16px rgba(23, 162, 184, 0.15);
  
  h3 {
    margin-top: 0;
    margin-bottom: 24px;
    color: #1a1a1a;
    font-size: 1.5em;
    font-weight: 600;
    letter-spacing: -0.3px;
  }
`;

const ResultItem = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
  font-size: 1rem;
  color: #666;
  
  strong {
    color: #333;
    font-weight: 600;
  }
`;

const TotalPrice = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px;
  margin-top: 24px;
  border-top: 3px solid #17a2b8;
  background: linear-gradient(135deg, #e7f3ff 0%, #d1ecf1 100%);
  border-radius: 8px;
  
  span:first-child {
    font-size: 1.2em;
    font-weight: 600;
    color: #333;
    letter-spacing: 0.2px;
  }
  
  span:last-child {
    font-size: 2em;
    font-weight: 700;
    color: #17a2b8;
    letter-spacing: -0.5px;
  }
`;

const DaysInfo = styled.div`
  font-size: 0.9em;
  color: #666;
  margin-top: 12px;
  text-align: right;
  font-style: italic;
  padding: 8px 12px;
  background: rgba(23, 162, 184, 0.05);
  border-radius: 6px;
  display: inline-block;
  float: right;
`;

const ResultsTable = styled.table`
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  margin: 20px 0;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
  
  th {
    background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
    color: white;
    padding: 16px 20px;
    text-align: left;
    font-weight: 600;
    font-size: 0.95em;
    letter-spacing: 0.3px;
    text-transform: uppercase;
  }
  
  td {
    padding: 16px 20px;
    border-bottom: 1px solid #e8e8e8;
    color: #333;
    background: white;
    font-size: 0.95em;
  }
  
  tbody tr:last-child td {
    border-bottom: none;
  }
  
  tbody tr:nth-child(even) td {
    background-color: #f9fafb;
  }
  
  tbody tr:hover td {
    background-color: #e7f3ff;
  }
`;

interface CalculationResult {
  fenceCount: number;
  stoneCount: number;
  totalLength: number;
}

export const Fence: React.FC = () => {
  const [lengthMeters, setLengthMeters] = useState<string>('3.5');
  const [heightMeters, setHeightMeters] = useState<string>('2.0');
  const [thicknessMm, setThicknessMm] = useState<string>('1.1');
  const [totalMeters, setTotalMeters] = useState<string>('');
  
  // Set default dates: today and 10 days from now
  const today = new Date();
  const tenDaysLater = new Date(today);
  tenDaysLater.setDate(today.getDate() + 10);
  
  const [startDate, setStartDate] = useState<string>(today.toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState<string>(tenDaysLater.toISOString().split('T')[0]);

  // Price calculation state
  const [showResults, setShowResults] = useState<boolean>(false);

  // Auto-adjust thickness when height is changed to 1.2m and 1.7mm is selected
  React.useEffect(() => {
    if (heightMeters === '1.2' && thicknessMm === '1.7') {
      setThicknessMm('1.1');
    }
  }, [heightMeters, thicknessMm]);

  // Auto-adjust to default values when switching to queue barriers (2.5m)
  React.useEffect(() => {
    if (lengthMeters === '2.5') {
      setHeightMeters('1.1'); // Queue barriers are fixed at 1.1m height
      setThicknessMm('1.1'); // Queue barriers don't have tube thickness options
    }
  }, [lengthMeters]);

  const calculation = useMemo((): CalculationResult => {
    const requestedM = Number(totalMeters) || 0;
    const fenceLength = Number(lengthMeters) || 3.5;

    if (requestedM <= 0) {
      return {
        fenceCount: 0,
        stoneCount: 0,
        totalLength: 0,
      };
    }

    // Calculate fence count: floor instead of ceil for exact fit
    const fenceCount = Math.floor(requestedM / fenceLength);
    // Stones = number of fences + 1 (one stone between each fence, plus end stones)
    const stoneCount = fenceCount + 1;
    const totalLength = fenceCount * fenceLength;

    return {
      fenceCount,
      stoneCount,
      totalLength,
    };
  }, [lengthMeters, totalMeters]);

  // Calculate rental price based on Fence-article-numbers.md tiered pricing
  const rentalPrice = useMemo(() => {
    if (!showResults || calculation.fenceCount === 0) return 0;

    // Get daily rate based on rental duration (tiered pricing)
    const getDailyRate = (days: number, baseRates: number[]) => {
      if (days <= 30) return baseRates[0];
      if (days <= 60) return baseRates[1];
      if (days <= 90) return baseRates[2];
      return baseRates[3]; // 90+ days
    };

    // Calculate rental days
    let days = 10; // minimum 10 days
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      days = Math.max(10, Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)));
    }

    // Tiered pricing from Fence-article-numbers.md
    // Fence panels: 88/44/22/11 kr per day (standard 2.0m height, 1.1mm)
    // Low fence (1.2m): 70/35/18/9 kr per day
    // Heavy duty (1.7mm): 88/44/22/11 kr per day
    // Stones: 16/8/4/2 kr per day
    
    const fenceRates = heightMeters === '1.2' ? [70, 35, 18, 9] : [88, 44, 22, 11];
    const stoneRates = [16, 8, 4, 2];

    const dailyFenceRate = getDailyRate(days, fenceRates);
    const dailyStoneRate = getDailyRate(days, stoneRates);

    // Calculate total price (no clamps)
    const totalPrice = (
      calculation.fenceCount * dailyFenceRate +
      calculation.stoneCount * dailyStoneRate
    ) * days;

    return Math.round(totalPrice);
  }, [calculation, heightMeters, thicknessMm, startDate, endDate, showResults]);

  const calculatorContent = (
    <Container>
      <FormContainer>
        {/* Length Selection */}
        <FormGroup>
          <Label>Tegund girðingar</Label>
          <RadioGroup>
            <RadioLabel>
              <RadioInput
                type="radio"
                name="length"
                value="3.5"
                checked={lengthMeters === '3.5'}
                onChange={(e) => setLengthMeters(e.target.value)}
              />
              Girðingar (3,5m)
            </RadioLabel>
            <RadioLabel>
              <RadioInput
                type="radio"
                name="length"
                value="2.5"
                checked={lengthMeters === '2.5'}
                onChange={(e) => setLengthMeters(e.target.value)}
              />
              Biðraðagirðingar (2,5m)
            </RadioLabel>
          </RadioGroup>
        </FormGroup>

        {/* Height Selection - only for standard fences (3.5m) */}
        {lengthMeters === '3.5' && (
          <FormGroup>
            <Label>Hæð í metrum</Label>
            <RadioGroup>
              <RadioLabel>
                <RadioInput
                  type="radio"
                  name="height"
                  value="2.0"
                  checked={heightMeters === '2.0'}
                  onChange={(e) => setHeightMeters(e.target.value)}
                />
                2,0 m
              </RadioLabel>
              <RadioLabel>
                <RadioInput
                  type="radio"
                  name="height"
                  value="1.2"
                  checked={heightMeters === '1.2'}
                  onChange={(e) => setHeightMeters(e.target.value)}
                />
                1,2 m
              </RadioLabel>
            </RadioGroup>
          </FormGroup>
        )}

        {/* Thickness Selection - only for standard fences (3.5m) */}
        {lengthMeters === '3.5' && (
          <FormGroup>
            <Label>Þykkt á túbu (mm)</Label>
            <RadioGroup>
              <RadioLabel>
                <RadioInput
                  type="radio"
                  name="thickness"
                  value="1.1"
                  checked={thicknessMm === '1.1'}
                  onChange={(e) => setThicknessMm(e.target.value)}
                />
                1,1 mm
              </RadioLabel>
              <RadioLabel style={{ opacity: heightMeters === '1.2' ? 0.5 : 1 }}>
                <RadioInput
                  type="radio"
                  name="thickness"
                  value="1.7"
                  checked={thicknessMm === '1.7'}
                  onChange={(e) => setThicknessMm(e.target.value)}
                  disabled={heightMeters === '1.2'}
                />
                1,7 mm {heightMeters === '1.2' && '(Aðeins fyrir 2,0 m hæð)'}
              </RadioLabel>
            </RadioGroup>
          </FormGroup>
        )}

        {/* Total Meters Input */}
        <FormGroup>
          <Label htmlFor="total-meters">Samtals metrar</Label>
          <TextInput
            id="total-meters"
            type="number"
            placeholder=""
            min="0"
            step="0.1"
            value={totalMeters}
            onChange={(e) => setTotalMeters(e.target.value)}
          />
        </FormGroup>

        {/* Date inputs */}
        <FormGroup>
          <Label htmlFor="start-date">Upphafsdagur</Label>
          <DateInput
            id="start-date"
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="end-date">Skiladagur</Label>
          <DateInput
            id="end-date"
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
          />
        </FormGroup>

        {/* Calculate Button */}
        <CalculateButton
          onClick={() => {
            if (totalMeters && Number(totalMeters) > 0) {
              setShowResults(true);
            }
          }}
        >
          Reiknaðu leiguverð
        </CalculateButton>

        {/* Results Display */}
        {showResults && calculation.fenceCount > 0 && (() => {
    // Calculate rental days
    let days = 10; // minimum 10 days
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      days = Math.max(10, Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)));
    }          // Get daily rate based on rental duration (tiered pricing)
          const getDailyRate = (days: number, baseRates: number[]) => {
            if (days <= 30) return baseRates[0];
            if (days <= 60) return baseRates[1];
            if (days <= 90) return baseRates[2];
            return baseRates[3]; // 90+ days
          };

          // Tiered pricing from Fence-article-numbers.md
          const fenceRates = heightMeters === '1.2' ? [70, 35, 18, 9] : [88, 44, 22, 11];
          const stoneRates = [16, 8, 4, 2];

          const dailyFenceRate = getDailyRate(days, fenceRates);
          const dailyStoneRate = getDailyRate(days, stoneRates);

          const fencePrice = dailyFenceRate;
          const stonePrice = dailyStoneRate;

          return (
            <ResultsSection>
              <h3>Niðurstöður</h3>
              <ResultsTable>
                <thead>
                  <tr>
                    <th>Vörunúmer</th>
                    <th>Lýsing</th>
                    <th>Magn</th>
                    <th>Verð/dag</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{
                      heightMeters === '2.0' && thicknessMm === '1.1' ? '01-BAT-GI01-015' :
                      heightMeters === '2.0' && thicknessMm === '1.7' ? '01-BAT-GI01-053' :
                      heightMeters === '1.2' && thicknessMm === '1.1' ? '01-BAT-GI01-052' : '01-BAT-GI01-015'
                    }</td>
                    <td>{
                      heightMeters === '2.0' && thicknessMm === '1.1' ? 'Girðingar 3.500x2.000x1,1mm' :
                      heightMeters === '2.0' && thicknessMm === '1.7' ? 'Girðingar 2000x3500x1,7mm' :
                      heightMeters === '1.2' && thicknessMm === '1.1' ? 'Girðingar 1200x3500x1,1mm' : 'Girðingar 3.500x2.000x1,1mm'
                    }</td>
                    <td>{calculation.fenceCount} stk</td>
                    <td>{fencePrice.toLocaleString('de-DE')} kr.</td>
                  </tr>
                  <tr>
                    <td>01-BAT-GI01-054</td>
                    <td>Steinar f/Girðingar</td>
                    <td>{calculation.stoneCount} stk</td>
                    <td>{stonePrice.toLocaleString('de-DE')} kr.</td>
                  </tr>
                </tbody>
              </ResultsTable>
              <TotalPrice>
                <span>Samtals leiguverð:</span>
                <span>{rentalPrice.toLocaleString('de-DE')} kr.</span>
              </TotalPrice>
              {startDate && endDate && (
                <DaysInfo>
                  ({Math.ceil((new Date(endDate).getTime() - new Date(startDate).getTime()) / (1000 * 60 * 60 * 24))} dagar)
                </DaysInfo>
              )}
            </ResultsSection>
          );
        })()}
      </FormContainer>
    </Container>
  );

  return (
    <PageContainer>
      <Section>
        <SectionTitle>Girðingar Reiknivél</SectionTitle>
        <SectionSubtitle>Reiknaðu leigukostnað fyrir girðingar</SectionSubtitle>
        {calculatorContent}
      </Section>
    </PageContainer>
  );
};
